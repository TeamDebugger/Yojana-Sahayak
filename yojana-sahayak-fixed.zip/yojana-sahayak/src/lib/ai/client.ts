import Anthropic from "@anthropic-ai/sdk";

// Server-side only. The API key is never sent to the browser.
export function llmConfigured(): boolean {
  return Boolean(process.env.ANTHROPIC_API_KEY && process.env.LLM_MODEL);
}

// Hindi (Devanagari) needs many more tokens than English, and the answer format ends with the
// official link and last-checked date, so a low limit would cut off exactly the parts that matter.
export const MAX_OUTPUT_TOKENS = 2048;

export type StreamPart = { delta: string } | { stop: string | null };

export async function* streamAnswer(
  system: string,
  messages: { role: "user" | "assistant"; content: string }[],
  signal?: AbortSignal,
): AsyncGenerator<StreamPart> {
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY, timeout: 30_000, maxRetries: 1 });
  const stream = await client.messages.create(
    { model: process.env.LLM_MODEL as string, max_tokens: MAX_OUTPUT_TOKENS, system, messages, stream: true },
    { signal },
  );
  let stop: string | null = null;
  for await (const event of stream) {
    if (signal?.aborted) return;
    if (event.type === "content_block_delta" && event.delta.type === "text_delta") yield { delta: event.delta.text };
    else if (event.type === "message_delta" && event.delta.stop_reason) stop = event.delta.stop_reason;
  }
  yield { stop };
}
